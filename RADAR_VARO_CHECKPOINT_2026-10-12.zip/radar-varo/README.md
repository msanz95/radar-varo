# RADAR VARO · FREE BETA

Estado de este checkpoint: **implementado localmente; publicación y ejecución automática pendientes**.

La referencia canónica está en `docs/canonical-reference.png`. Sus cifras son ilustrativas y no alimentan los datos. La aplicación publicada sirve únicamente `web/`; ni las pruebas ni los ejemplos se incluyen en su feed.

## Implementación

- PWA móvil con identidad azul/negro, cian y violeta, radar ilustrativo de México, KPIs, Alertas/Telcel/Movimientos, categorías procedentes de datos, evidencia de precio y preferencias locales del feed.
- Motor Python sin servidor permanente: SKU independiente, histórico compacto, nueve eventos, caducidad de oportunidades y anomalías basadas en observaciones propias.
- Adaptador HTTP que falla de forma explícita ante el shell JavaScript actual de Telcel.
- Adaptador de DOM renderizado para GitHub Actions. Sus selectores de tarjetas, paginación, SKU, precio total, precio anterior y botón de compra se inspeccionaron en el sitio público real. Falta ejecutar y ajustar este adaptador en el runner de producción.
- Programación disjunta: cada 15 minutos normal, cada 5 en 02:00–04:59 CDMX, con exclusión mutua y guard de última ejecución. Son objetivos, sujetos a cola de GitHub y duración del barrido.
- Pages publica el mismo snapshot que se guardó en Git. Datos JSON siempre se solicitan sin caché; el service worker no conserva precios.
- ntfy opcional con topic largo en `NTFY_TOPIC`, nunca en código, JSON público o interfaz. La app funciona sin topic; no se ha enviado ni prometido ninguna notificación.

## Comprobaciones ejecutadas

`python -m unittest discover -s tests -v`: 26 pruebas aprobadas.

`python -m radar.verify`: integridad del paquete y correspondencia UI/JSON aprobadas.

Sintaxis JavaScript y Python validada. No se ejecutó el QA visual de la PWA en este entorno. `tests/browser_qa.py` está preparado para validar 360×800, 390×844 y 1365×960 en GitHub Actions, antes del despliegue.

Consulta real HTTP: 743 URLs de producto descubiertas (599 smartphones, 88 accesorios, 39 vida conectada, 17 tablets), cero precios verificables por HTTP. Los cuatro SOURCE_ERROR se conservan en `web/data/`. Los números son evidencia de descubrimiento; no son inventario ni precios monitorizados.

Inspección real posterior en navegador: la tarjeta y ficha de `71001914` (iPhone 16e 128GB negro) concordaron en $12,799.00 MXN, con precio anterior publicado $14,999.00. Esta inspección valida selectores y una fixture; no equivale a un barrido automático. Véase `evidence/live-dom-inspection.json`.

## Continuación de publicación

1. Iniciar sesión de GitHub en el acceso seguro de la conversación. El conector ya identifica al propietario, pero el navegador no comparte su sesión.
2. Crear el repositorio público `radar-varo` en la cuenta del usuario y subir este contenido con rama `main`. No reutilizar otro proyecto no relacionado.
3. Activar Pages con origen GitHub Actions. Verificar permisos de Actions y la ejecución del workflow.
4. Ejecutar el primer workflow, inspeccionar evidencia real del lector renderizado y corregir cualquier selector o paginación que falle. No sustituir errores por datos de prueba.
5. Confirmar los resultados de QA móvil/escritorio, caché y URL HTTPS en una sesión nueva. Verificar también un disparo programado, no sólo manual.
6. Sólo después declarar publicada la app y entregar la URL devuelta por Pages. ntfy seguirá opcional hasta configurar y comprobar recepción en el teléfono.

## Comandos

```bash
python -m unittest discover -s tests -v
python -m radar.scan --force
python -m radar.verify
```

En el runner de GitHub:

```bash
pip install -r requirements-renderer.txt
python -m playwright install --with-deps chromium
python -m radar.scan --rendered
python tests/browser_qa.py
```

No instalar ni controlar otro navegador en el entorno administrado de Work para eludir sus reglas de QA. La inspección del sitio externo se efectuó mediante su navegador autorizado.

## Límites que deben conservarse visibles

- El recorrido es progresivo y guarda el enlace de siguiente página cuando agota el presupuesto. Puede haber cobertura parcial y precios anteriores; la UI muestra su hora real y excluye ofertas caducadas del feed accionable.
- Un precio de listado que dice «desde» se etiqueta como tal. No basta para S+/S++; se necesita corroborar SKU/precio exacto/disponibilidad en la ficha.
- Las variantes adicionales que no aparecen en listados todavía requieren ampliar el recorrido público. El sitemap no se presenta como catálogo monitorizado completo.
- Un producto ausente del listado puede haber cambiado de color representativo. El adaptador exige comprobación directa de ausencia antes de avanzar su contador; un error de lectura no borra histórico.
- La cadencia de GitHub Actions no es una garantía de tiempo real. La compactación limita JSON, no el tamaño acumulado de todo el historial Git a largo plazo.
- La notificación usa un registro de recibos: dos barridos iguales confirmados no se notifican de nuevo. Un corte entre el envío externo y su persistencia puede producir una duplicación excepcional; no se promete entrega exactamente una vez.
- ROI, liquidez, ganancia y referencias internacionales todavía no se calculan para ofertas reales. El módulo económico está aislado para ampliación futura.

Referencias operativas consultadas: [Telcel robots](https://www.telcel.com/robots.txt), [condiciones de tienda](https://www.telcel.com/personas/equipos/terminos-y-condiciones), [GitHub schedules](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows), [Playwright CI](https://playwright.dev/python/docs/ci), [ntfy](https://docs.ntfy.sh/publish/).
